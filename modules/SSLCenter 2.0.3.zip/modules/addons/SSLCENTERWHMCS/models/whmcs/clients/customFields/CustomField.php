<?php

namespace MGModule\SSLCENTERWHMCS\models\whmcs\clients\customFields;
use MGModule\SSLCENTERWHMCS as main;

class CustomField{
    public $id;
    public $name;
    public $value;
}