<?php

namespace MGModule\SSLCENTERWHMCS\mgLibs\forms;
use MGModule\SSLCENTERWHMCS as main;

/**
 * Form Legend
 *
 * @author Michal Czech <michael@modulesgarden.com>
 */
class LegendField extends AbstractField{
    public $type    = 'legend';
}
