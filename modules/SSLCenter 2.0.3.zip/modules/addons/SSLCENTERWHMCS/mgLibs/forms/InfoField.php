<?php

namespace MGModule\SSLCENTERWHMCS\mgLibs\forms;

use MGModule\SSLCENTERWHMCS as main;

/**
 * Info 
 */
class InfoField extends AbstractField
{
    public $type   = 'info';
    public $values = [];
    public $h      = false;
    public $strong = false;
}
