<?php

namespace MGModule\SSLCENTERWHMCS\mgLibs\forms;
use MGModule\SSLCENTERWHMCS as main;

/**
 * Button Hidden Input Field
 *
 * @author Michal Czech <michael@modulesgarden.com>
 */
class HiddenField extends AbstractField{
    public $type    = 'hidden';
}
